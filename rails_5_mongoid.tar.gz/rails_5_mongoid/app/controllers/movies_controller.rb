class MoviesController < ApplicationController
  def index
    @titles ="Movies Index"
    @id1 = "id1"
    @id2 = "id2"
    @class1 = "class1"
    @class2 = "class2"
    @title = "Movie Title"
    @awesome = "Awesome"
    #@test = "reddish"
    @movie = Movie.first
  end
end
