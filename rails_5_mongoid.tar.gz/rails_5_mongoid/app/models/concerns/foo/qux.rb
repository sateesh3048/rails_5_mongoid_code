module Foo
  Qux = "I'm at the Foo!"
end