class Foo::Bar
  def self.print_qux
    puts Qux
  end
end