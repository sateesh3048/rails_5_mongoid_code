module Foo
end