class Address
  include Mongoid::Document
  
  # field names
  field :street, type: String
  field :city, type: String
  field :country, type: String
  field :pincode, type: Integer

  #Associations
  embedded_in :person
end
