class Person
  include Mongoid::Document
  include Mongoid::Timestamps

  # field names
  field :age, type: Integer
  field :monthly_cost, type: Float
  field :first_name, type: String
  field :is_active, type: Boolean, default: true
  field :birth_date, type: Date
  field :favorate_time, type: DateTime
  field :first_company_joined_date, type: Time, default: -> { Time.now-7.years }
  field :habbits, type: Array
  field :url, type: Hash
  field :profile_pic, type: BSON::Binary
  field :last_name, type: String
  field :email, type: String
  field :notes, type: String#, localize: true

  #attr_readonly :email
  
  # Associations
  embeds_many :addresses


  def full_name
    [first_name, last_name].join(" ")
  end
end
