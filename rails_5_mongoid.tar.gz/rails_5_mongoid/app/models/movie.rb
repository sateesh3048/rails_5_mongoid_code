class Movie
  include Mongoid::Document
  field :name, type: String
  field :release_date, type: Time
  field :actor_name, type: String
  field :budget, type: BigDecimal

  def haml_object_ref
    "special_movie"
  end
end
