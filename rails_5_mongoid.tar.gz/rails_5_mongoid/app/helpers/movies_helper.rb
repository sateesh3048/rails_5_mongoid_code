module MoviesHelper

  def para_hash
    {:id => [@id1, @id2], :class => [@class1, @class2]}
  end
end
